import { Meteor } from 'meteor/meteor';
import { Mongo } from 'meteor/mongo';
import { check } from 'meteor/check';
//import '../imports/api/login.js';

Meteor.startup(() => {
  // code to run on server at startup
  
});

Meteor.methods({
  'UpdateUserRegistrationDetails'(firstName,lastName) {
    check(firstName, String);
	check(lastName, String);
 
    // Make sure the user is logged in before updating user details
    if (! this.userId) {
      throw new Meteor.Error('not-authorized');
    }
 
    Meteor.users.update( 
	{ _id: Meteor.userId() },
	//this.userId, // Filter criteria
	{ $set:
		{
		"profile.firstName": firstName,
		"profile.lastName": lastName
      //username: Meteor.users.findOne(this.userId).username,
    }});
  }
  });