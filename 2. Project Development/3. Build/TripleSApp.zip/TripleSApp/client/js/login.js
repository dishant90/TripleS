import { Template } from 'meteor/templating';
import { ReactiveVar } from 'meteor/reactive-var';

//import { ApplicationUsers } from '../../imports/api/login.js';
import '../../imports/api/login.js';
import '../html/login.html';

Template.index.onCreated(function helloOnCreated() {
  // counter starts at 0
  //this.hasToRegister = new ReactiveVar(false);
  Session.set( "hasToRegister", false );
  
});

Template.LoginPage.onCreated(function helloOnCreated() {
  // counter starts at 0
  //this.hasToRegister = new ReactiveVar(false);
  //Session.set( "hasToRegister", false );
  
});

Template.index.helpers({
  hasToRegister: function() {
    // Here we get our template instance from Template.instance() and
    // can access hasToRegister from it.
    return Session.get("hasToRegister");
  }
});

Template.RegisterPage.events({
    'submit form': function(event) {
        event.preventDefault();
		
		var firstNameVar = event.target.registerFirstName.value;
		var lastNameVar = event.target.registerLastName.value;
        var emailVar = event.target.registerEmail.value;
        var passwordVar = event.target.registerPassword.value;
	
        Accounts.createUser({
            email: emailVar,
            password: passwordVar
        }, function(error,response){
			if(error){
				alert(error.reason); // Output error if registration fails
			}
			else {
				alert('User Registration Successful');
				Meteor.call('UpdateUserRegistrationDetails',firstNameVar,lastNameVar);
			}
		});
    }
});

Template.LoginPage.events({
    'submit form': function(event){
        event.preventDefault();
        var emailVar = event.target.loginEmail.value;
        var passwordVar = event.target.loginPassword.value;
        Meteor.loginWithPassword(emailVar, passwordVar, function(error) {
			if(error){
				alert(error.reason); // Output error if login fails
			}
		});
    },
	
	'click .js-createAccount': function(event,template){
        event.preventDefault();
        //template.hasToRegister.set( true );
		Session.set( "hasToRegister", true );
    }
});