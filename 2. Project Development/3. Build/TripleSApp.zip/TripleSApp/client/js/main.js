import { Template } from 'meteor/templating';
import { ReactiveVar } from 'meteor/reactive-var';

import '../html/main.html';

Template.MasterPage.onCreated(function helloOnCreated() {
  // counter starts at 0
  this.counter = new ReactiveVar(0);
  Session.set( "displayNewCase", false );
});

Template.MasterPage.helpers({
  counter() {
    return Template.instance().counter.get();
  },
  currentUserFirstName() {
	return Meteor.user().profile.firstName;
  },
  displayNewCase() {
	return Session.get("displayNewCase");
  }
});

Template.MasterPage.events({
  'click button'(event, instance) {
    // increment the counter when button is clicked
    instance.counter.set(instance.counter.get() + 1);
  },
});

Template.MasterPage.events({
    'click #userLogout': function(event){
        event.preventDefault();
		Session.set( "hasToRegister", false );
        Meteor.logout();
    },
	'click #newCase': function(event){
        event.preventDefault();
		Session.set( "displayNewCase", true );
    }
});
